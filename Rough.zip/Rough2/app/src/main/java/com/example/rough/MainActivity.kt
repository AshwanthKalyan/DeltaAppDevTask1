package com.example.rough

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.annotation.ColorRes
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private var clickCount = 0
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val but1 = findViewById<Button>(R.id.button1)
        val but2 = findViewById<Button>(R.id.button2)
        val but3 = findViewById<Button>(R.id.button3)
        val but4 = findViewById<Button>(R.id.button4)
        val but5 = findViewById<Button>(R.id.button5)
        val but6 = findViewById<Button>(R.id.button6)
        val but7 = findViewById<Button>(R.id.button7)
        val but8 = findViewById<Button>(R.id.button8)
        val but9 = findViewById<Button>(R.id.button9)
        val but10 = findViewById<Button>(R.id.button10)
        val but11 = findViewById<Button>(R.id.button11)
        val but12 = findViewById<Button>(R.id.button12)
        val but13 = findViewById<Button>(R.id.button13)
        val but14 = findViewById<Button>(R.id.button14)
        val but15 = findViewById<Button>(R.id.button15)
        val but16 = findViewById<Button>(R.id.button16)
        val but17 = findViewById<Button>(R.id.button17)
        val but18 = findViewById<Button>(R.id.button18)
        val but19 = findViewById<Button>(R.id.button19)
        val but20 = findViewById<Button>(R.id.button20)
        val but21 = findViewById<Button>(R.id.button21)
        val but22 = findViewById<Button>(R.id.button22)
        val but23 = findViewById<Button>(R.id.button23)
        val but24 = findViewById<Button>(R.id.button24)
        val but25 = findViewById<Button>(R.id.button25)

        val mainlayout = findViewById<View>(R.id.main)

        if (but25.text.toString().toInt() < 4) {
            but25.setBackgroundColor(Color.parseColor("#ff6750a4"))

        }

        var buttonIds = intArrayOf(
            (R.id.button1),
            (R.id.button2),
            (R.id.button3),
            (R.id.button4),
            (R.id.button5),
            (R.id.button6),
            (R.id.button7),
            (R.id.button8),
            (R.id.button9),
            (R.id.button10),
            (R.id.button11),
            (R.id.button12),
            (R.id.button13),
            (R.id.button14),
            (R.id.button15),
            (R.id.button16),
            (R.id.button17),
            (R.id.button18),
            (R.id.button19),
            (R.id.button20),
            (R.id.button21),
            (R.id.button22),
            (R.id.button23),
            (R.id.button24),
            (R.id.button25)
        )
        var a = 0
        var b = 0
        mainlayout.setBackgroundColor(Color.BLUE)

        for (buttonId in buttonIds) {



            findViewById<Button>(buttonId).setOnClickListener {
                b++
                if (b % 2 == 1) {
                    findViewById<Button>(buttonId).setBackgroundColor(Color.BLUE)
                } else {
                    findViewById<Button>(buttonId).setBackgroundColor(Color.RED)
                }

                if (a % 2 == 0) {
                    mainlayout.setBackgroundColor(Color.RED)
                    a++

                } else {
                    mainlayout.setBackgroundColor(Color.BLUE)
                    a++
                }

                val currentnumber = findViewById<Button>(buttonId).text.toString().toInt()
                
                if (currentnumber + 1 <= 0) {
                    findViewById<Button>(buttonId).setTextColor(Color.BLACK)
                } else {
                    findViewById<Button>(buttonId).setTextColor(Color.WHITE)
                }

                if (b < 3) {
                    findViewById<Button>(buttonId).text = (currentnumber + 3).toString()

                } else {
                    findViewById<Button>(buttonId).text = (currentnumber + 1).toString()
                }

                if (currentnumber == 3) {

                    findViewById<Button>(buttonId).text = (0).toString()
                    findViewById<Button>(buttonId).setTextColor(Color.parseColor("#ff6750a4"))

                    val index = buttonIds.indexOf(buttonId)
                    val currentnumber1 =
                        findViewById<Button>(buttonIds[index - 5]).text.toString().toInt()
                    val currentnumber2 =
                        findViewById<Button>(buttonIds[index + 5]).text.toString().toInt()
                    val currentnumber3 =
                        findViewById<Button>(buttonIds[index - 1]).text.toString().toInt()
                    val currentnumber4 =
                        findViewById<Button>(buttonIds[index + 1]).text.toString().toInt()
                    val row = index / 5
                    val col = index % 5
                    if (row > 0) {
                        findViewById<Button>(buttonIds[index - 5]).text =
                            (currentnumber1 + 1).toString()
                        if (b % 2 == 1) {
                            findViewById<Button>(buttonIds[index - 5]).setBackgroundColor(Color.BLUE)
                        } else {
                            findViewById<Button>(buttonIds[index - 5]).setBackgroundColor(Color.RED)
                        }

                    }
                    if (row < 4) {
                        findViewById<Button>(buttonIds[index + 5]).text =
                            (currentnumber2 + 1).toString()
                        if (b % 2 == 1) {
                            findViewById<Button>(buttonIds[index + 5]).setBackgroundColor(Color.BLUE)
                        } else {
                            findViewById<Button>(buttonIds[index + 5]).setBackgroundColor(Color.RED)
                        }

                    }
                    if (col > 0) {
                        findViewById<Button>(buttonIds[index - 1]).text =
                            (currentnumber3 + 1).toString()
                        if (b % 2 == 1) {
                            findViewById<Button>(buttonIds[index - 1]).setBackgroundColor(Color.BLUE)
                        } else {
                            findViewById<Button>(buttonIds[index - 1]).setBackgroundColor(Color.RED)
                        }

                    }
                    if (col < 4) {
                        findViewById<Button>(buttonIds[index + 1]).text =
                            (currentnumber4 + 1).toString()
                        if (b % 2 == 1) {
                            findViewById<Button>(buttonIds[index + 1]).setBackgroundColor(Color.BLUE)
                        } else {
                            findViewById<Button>(buttonIds[index + 1]).setBackgroundColor(Color.RED)
                        }

                    }
                }
            }

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(
                    systemBars.left,
                    systemBars.top,
                    systemBars.right,
                    systemBars.bottom
                )
                insets
            }



            }
        }



    }
